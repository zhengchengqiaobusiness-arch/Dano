# PointLion 我的待办查询 Skill

## 只需要改 Token

打开：

```text
scripts/config.py
```

只修改这一行：

```python
TOKEN = "你的真实Token"
```

其它地址、接口、字段、枚举解析逻辑均已配置好，不需要设置环境变量。

然后直接运行：

```bash
python3 scripts/pointlion_todo.py doctor
python3 scripts/pointlion_todo.py enums --with-dicts --format table
python3 scripts/pointlion_todo.py query --所属流程 "请假申请" --format table
```

Token 可以带 `Bearer ` 前缀，也可以只填 Token 本体。
