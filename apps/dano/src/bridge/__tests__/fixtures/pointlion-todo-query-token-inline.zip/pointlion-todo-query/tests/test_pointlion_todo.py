#!/usr/bin/env python3
import json
import subprocess
import sys
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "pointlion_todo.py"
CONFIG = ROOT / "scripts" / "config.py"


class Handler(BaseHTTPRequestHandler):
    last_todo_query = None
    last_auth = None
    last_tenant = None

    def log_message(self, fmt, *args):
        pass

    def _send(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlparse(self.path)
        Handler.last_auth = self.headers.get("Authorization")
        Handler.last_tenant = self.headers.get("tenant-id")
        if parsed.path == "/admin-api/bpm/category/simple-list":
            return self._send({"code": 0, "data": [
                {"id": 1, "name": "行政流程", "code": "OA"},
                {"id": 2, "name": "人事流程", "code": "HR"},
            ], "msg": ""})
        if parsed.path == "/admin-api/bpm/process-definition/simple-list":
            return self._send({"code": 200, "data": {"list": [
                {"id": "leave:3:100", "name": "请假申请", "key": "leave", "category": "OA", "categoryName": "行政流程", "version": 3, "suspensionState": 1},
                {"id": "leave:2:090", "name": "请假申请", "key": "leave", "category": "OA", "categoryName": "行政流程", "version": 2, "suspensionState": 1},
                {"id": "expense:2:200", "name": "费用报销", "key": "expense", "category": "OA", "categoryName": "行政流程", "version": 2, "suspensionState": 1},
            ], "total": 3}})
        if parsed.path == "/admin-api/system/dict-data/simple-list":
            return self._send({"code": 0, "data": [
                {"dictType": "bpm_task_status", "label": "审批中", "value": "1"},
                {"dictType": "bpm_task_status", "label": "审批通过", "value": "2"},
                {"dictType": "bpm_process_instance_status", "label": "审批中", "value": "1"},
                {"dictType": "bpm_process_instance_status", "label": "审批通过", "value": "2"},
                {"dictType": "system_user_sex", "label": "男", "value": "1"},
            ]})
        if parsed.path == "/admin-api/bpm/task/todo-page":
            Handler.last_todo_query = parse_qs(parsed.query, keep_blank_values=True)
            return self._send({"code": 0, "data": {"list": [
                {
                    "id": "task-001",
                    "name": "领导审批",
                    "status": 1,
                    "taskDefinitionKey": "leaderApprove",
                    "createTime": "2026-09-04 09:52:00",
                    "processInstanceId": "pi-001",
                    "processInstance": {
                        "id": "pi-001",
                        "name": "请假申请",
                        "billCode": "QJD202609040001",
                        "summary": [
                            {"key": "请假类型", "value": "年假"},
                            {"key": "天数", "value": 1},
                        ],
                        "status": 1,
                        "category": "OA",
                        "categoryName": "行政流程",
                        "createTime": "2026-09-04 09:51:47",
                        "startUser": {"id": 1, "nickname": "管理员"},
                        "processDefinition": {
                            "id": "leave:3:100", "key": "leave", "name": "请假申请", "version": 3
                        }
                    }
                }
            ], "total": 1}})
        return self._send({"error": "not found"}, 404)


class SkillTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_address[1]}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.thread.join(timeout=2)

    def run_cli(self, *args):
        # Use hidden temporary CLI overrides only for the local mock server.
        # Production usage reads TOKEN directly from scripts/config.py.
        cmd = [
            sys.executable, str(SCRIPT),
            "--base-url", self.base,
            "--token", "test-token",
            "--tenant-id", "9",
            *args,
        ]
        return subprocess.run(cmd, text=True, capture_output=True, timeout=10)

    def test_enums_and_wrapper_shapes(self):
        p = self.run_cli("enums")
        self.assertEqual(p.returncode, 0, p.stderr)
        data = json.loads(p.stdout)
        self.assertEqual(data["category"][0]["code"], "OA")
        self.assertEqual(data["processDefinition"][0]["key"], "leave")
        self.assertEqual(Handler.last_auth, "Bearer test-token")
        self.assertEqual(Handler.last_tenant, "9")

    def test_bpm_dict_enums(self):
        p = self.run_cli("enums", "--with-dicts")
        self.assertEqual(p.returncode, 0, p.stderr)
        data = json.loads(p.stdout)
        self.assertTrue(any(x.get("dictType") == "bpm_task_status" for x in data["dictData"]))
        self.assertFalse(any(x.get("dictType") == "system_user_sex" for x in data["dictData"]))

    def test_resolve_chinese_names_and_query_fields(self):
        p = self.run_cli(
            "query",
            "--task-name", "领导审批",
            "--category", "行政流程",
            "--process", "请假申请",
            "--start-time", "2026-09-01",
            "--end-time", "2026-09-04",
            "--page", "1",
            "--page-size", "20",
        )
        self.assertEqual(p.returncode, 0, p.stderr)
        data = json.loads(p.stdout)
        q = Handler.last_todo_query
        self.assertEqual(q["pageNo"], ["1"])
        self.assertEqual(q["pageSize"], ["20"])
        self.assertEqual(q["name"], ["领导审批"])
        self.assertEqual(q["category"], ["OA"])
        self.assertEqual(q["processDefinitionKey"], ["leave"])
        self.assertEqual(data["resolved"]["process"]["id"], "leave:3:100")
        self.assertEqual(q["createTime[0]"], ["2026-09-01 00:00:00"])
        self.assertEqual(q["createTime[1]"], ["2026-09-04 23:59:59"])
        item = data["items"][0]
        self.assertEqual(item["display"]["单据编号"], "QJD202609040001")
        self.assertEqual(item["display"]["流程"], "请假申请")
        self.assertEqual(item["display"]["发起人"], "管理员")
        self.assertEqual(item["display"]["当前任务"], "领导审批")
        self.assertEqual(item["task"]["statusLabel"], "审批中")
        self.assertEqual(item["processInstance"]["statusLabel"], "审批中")
        self.assertIn("请假类型: 年假", item["display"]["摘要"])

    def test_query_json_chinese_aliases(self):
        query = json.dumps({
            "任务名称": "领导审批",
            "流程分类": "OA",
            "所属流程": "请假申请",
            "发起时间": ["2026年9月1日", "2026年9月4日"],
            "页码": 2,
            "每页": 5,
        }, ensure_ascii=False)
        p = self.run_cli("query", "--query-json", query)
        self.assertEqual(p.returncode, 0, p.stderr)
        q = Handler.last_todo_query
        self.assertEqual(q["pageNo"], ["2"])
        self.assertEqual(q["pageSize"], ["5"])
        self.assertEqual(q["category"], ["OA"])
        self.assertEqual(q["processDefinitionKey"], ["leave"])

    def test_doctor(self):
        p = self.run_cli("doctor")
        self.assertEqual(p.returncode, 0, p.stderr)
        data = json.loads(p.stdout)
        self.assertTrue(data["ok"])
        self.assertTrue(data["endpoints"]["todoPage"]["ok"])


if __name__ == "__main__":
    unittest.main()
