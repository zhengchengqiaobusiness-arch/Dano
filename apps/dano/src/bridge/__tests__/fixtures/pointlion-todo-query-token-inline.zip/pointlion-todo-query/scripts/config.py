# -*- coding: utf-8 -*-
"""PointLion 待办查询 Skill 固定配置。

正常使用时，只需要修改 TOKEN 这一行。
"""

# ======================== 只修改这一行 ========================
TOKEN = "把你的Token粘贴到这里"
# =============================================================

# 以下配置已经按当前 OA 地址固定，正常情况下不要修改。
BASE_URL = "http://admin.dianshixinxi.com:90"
API_PREFIX = "/admin-api"
TODO_PATH = "/bpm/task/todo-page"
CATEGORY_PATH = "/bpm/category/simple-list"
PROCESS_DEFINITION_PATH = "/bpm/process-definition/simple-list"
DICT_DATA_PATH = "/system/dict-data/simple-list"

# 当前 Skill 默认按单租户/Token 自包含方式调用。若 Token 是 JWT 且包含
# tenantId / tenant_id / tenant claim，脚本会自动提取并发送 tenant-id。
TENANT_ID = ""
TENANT_HEADER = "tenant-id"
TIMEOUT = 15.0
